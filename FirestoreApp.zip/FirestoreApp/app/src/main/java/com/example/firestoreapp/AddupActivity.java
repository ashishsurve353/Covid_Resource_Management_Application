package com.example.firestoreapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class AddupActivity extends AppCompatActivity {
    public static final String TAG = "TAG";
    TextView Name;
    EditText goods,quantity,location;
    Button add;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addup);
        Name = findViewById(R.id.aName);
        goods = findViewById(R.id.aDonate);
        quantity = findViewById(R.id.aQuantity);
        location = findViewById(R.id.aLocation);
        add = findViewById(R.id.Addbt);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                Name.setText(documentSnapshot.getString("Name of the Organization"));
            }
        });



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Agoods = goods.getText().toString().trim();
                String Aquantity = quantity.getText().toString().trim();
                String Alocation = location.getText().toString().trim();

                if(TextUtils.isEmpty(Agoods))
                {
                    goods.setError("Goods is Required");
                    return;
                }
                if(TextUtils.isEmpty(Aquantity))
                {
                    quantity.setError("Quantity is Required");
                    return;
                }
                if(TextUtils.isEmpty(Alocation))
                {
                    location.setError("Location is Required");
                    return;
                }
            }
        });

    }
}
